// Initial connection probe. All networking runs in OBSWebSocket.dll on the PC.
function InitOBSStatus(skin)
{
    skin.data = {
        text: this.FindLayout("StatusText"),
        last: ""
    };
}

function TickOBSStatus(skin)
{
    var d = skin.data;
    if (!d || !d.text) return;
    // IIncomingDataSource values are not exposed through CallFunc (the
    // IFuncProvider-only route). Power-Grid's native data-source bridge
    // calls OBSWebSocket::GetValue("TileStatus", []) directly.
    var state = (typeof this.CallDataSourceFunc === "function")
        ? this.CallDataSourceFunc("OBSWebSocket", "TileStatus", [])
        : null;
    var message = "OBS WebSocket\n";
    if (state === null || state === undefined || typeof state !== "string" || state === "")
        message += "Status unavailable (check data source)";
    else message += String(state);
    if (message != d.last) {
        d.text.setText(message);
        d.last = message;
        this.Invalidate();
    }
}
