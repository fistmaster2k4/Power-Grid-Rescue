# OBS WebSocket for ROCCAT Power-Grid — v0.1.15 source

**Status: v0.1.15 confirmed working in the restored Power-Grid host and
on its Android controller (1 November 2026).** The original-style purple
radial mask persists after adjustment, and volume changes made directly in
OBS update the grid automatically, with a small refresh delay.
This package intentionally does **not** contain a DLL or an installable RPGP. Build the
Windows x86 DLL in the Power-Grid PDK, place it beside the package definition, then
create the RPGP. v0.1.11's three source-selection dropdowns were confirmed
working in the restored Power-Grid host. The v0.1.12 test showed `0` on every
grid label and volume, because the JavaScript control was calling the native
`IFuncProvider` route while our DLL implements `IIncomingDataSource`. v0.1.13
fixed the bridge through `CallDataSourceFunc()`, and the user confirmed live
volume/mute control for all three sources. v0.1.14 restored the original
smooth radial fill, but the host reset its synthetic function result to zero
after rotary interaction, making the light go black. v0.1.15 detects and
restores that mask result during each regular update without changing OBS's
actual volume. This source is intended
to be overlaid onto the existing PDK working project, not installed as a
second project.

## Scope

- Connects to **OBS WebSocket v5.x**, normally `ws://127.0.0.1:4455`.
- Supports the `Hello` / `Identify` / `Identified` handshake, including the
  official salted SHA-256 authentication challenge.
- Uses JSON WebSocket frames and the official v5 opcodes.
- Discovers inputs (`GetInputList`), reads volume/mute states, and listens for
  `InputVolumeChanged` and `InputMuteStateChanged` events.
- Retrieves device settings and available device-property choices for audio
  inputs, using Windows device-friendly names exposed by OBS when possible.
- Offers **three independent source selectors**, each with a user-editable
  button label (defaults: AUDIO 1, AUDIO 2, AUDIO 3).
- Offers a **4x3 OBS Volume Mixer** based on the original ROCCAT rotary layout.
  The three custom-name buttons choose which OBS source the dial and central
  mute control operate; source assignments come from the OBS settings panel.
- Duplicates the original graphics under unique `OBS_` names and recolors the
  blue light effects to Twitch-like purple. The built-in system volume control
  and its blue graphics are **not** modified.
- Preserves the original single-image **radial mask** on the purple rotary:
  partial segments are smoothly clipped, not toggled on and off as LEDs.
  A local `OBSVolumeMaskFeed` Percent output is populated from OBS by the
  skin's `SetFuncRes(0,0,volume)` call. This function-result channel is a UI
  feed, not an additional OBS WebSocket endpoint.
- Schedules host-side refresh with `SetTickInterval(250)` and invalidates the
  grid when volume, mute or button-label state changes. It also checks
  `GetFuncRes(0,0)` against the selected OBS level: if the host has reset that
  synthetic output, `SetFuncRes(0,0,volume)` restores the mask and forces
  a redraw even when the OBS level itself has not changed.
- Provides a scalar `TileStatus` function for the 1x2 status control. The
  script calls it through `CallDataSourceFunc("OBSWebSocket", "TileStatus", [])`.
  `CallFunc("OBSWebSocket:...", ...)` returns `0` for this incoming-source DLL;
  it is the separate function-provider interface, not an alias for `GetValue()`.
- Exposes functions to custom Power-Grid JavaScript controls.
- Reconnects after OBS closes or restarts.
- Restricts remote connections: only `127.0.0.1` or `localhost` is accepted.
- Does **not** subscribe to high-frequency audio meters. No unnecessary GPU or
  Android-rendering work.

No Twitch API integration, scene control or OBS UI dock is included; purple
is the mixer accent color, not a separate Twitch connection.

## SDK / build prerequisites

- Windows **x86** target, Qt **4.8.x** with QtCore, QtNetwork, QtScript and QtGui.
- A compatible MSVC/Qt build configuration provided by the Power-Grid PDK.
- Original Power-Grid 1.1 SDK `include/RoccatPowerGrid.h` and
  `lib/RoccatPowerGrid.lib` (or the PDK-equivalent binary-compatible library).

`Source/OBSWebSocket.pro` expects those two SDK items in a sibling directory:

```text
PowerGridSDK/
  include/RoccatPowerGrid.h
  lib/RoccatPowerGrid.lib
OBSWebSocket_v0.1.10/
  Source/OBSWebSocket.pro
  Source/obswebsocket.h
  Source/obswebsocket.cpp
```

The PDK detects C++ sources in `Source/` (capital S). Adjust the `.pro`
include/library paths to your PDK workspace if necessary.
Build the `OBSWebSocket` target as an **x86 Qt plugin**. Qt4's `moc` must run for
the `Q_OBJECT`/`Q_INTERFACES` class. The output must be `OBSWebSocket.dll`.

## Packaging after a successful DLL build

Keep `icon.png` at the package root alongside the DLL, `plugin.json`,
`OBSWebSocket.qs`, `OBSVolume.qs`, `OBSWebSocket.ctrlset.json` and `info.json`.
All 12 custom mixer PNG assets belong under `rsc/`; the manifest references
their relative `rsc/` paths. ZIP the package contents with that directory
structure preserved, then rename the ZIP to `OBSWebSocket_v0.1.15.rpgp`.

## First connection test

1. In OBS **Tools → WebSocket Server Settings**, enable the WebSocket server and
   authentication, noting the actual port and password.
2. Install the compiled Power-Grid package.
3. Open **Settings → OBS WebSocket Settings** and enter the port and password.
   Click **Apply** to save those fields, then click **Connect**. It does not
   connect on load or merely when credentials are entered.
   The single **Connect / Disconnect** button toggles the connection. The
   status label beneath it reports whether OBS is currently connected.
   The host renders button `Text` literally, so a dynamic button caption is
   not supported through this config property.
4. After a successful manual connection, you may enable **Automatically connect
   on startup**, then click **Apply** again to retain the successful-connection
   marker. Otherwise the plugin remains manually connected only.
5. In **Audio Source Buttons**, choose three audio sources. The native
   dropdowns display their Windows device-friendly names where OBS exposes
   them. Rename the three button captions as desired; click **Apply**.
6. Add `[Plugin] OBS WebSocket → OBS Connection Status (1x2)` to a grid
   (one row, two columns). Confirm it shows **Connected (N audio inputs)**
   rather than **Plugin DLL missing** while the connection works.
7. Add `[Plugin] OBS WebSocket → Audio → OBS Volume Mixer (4x3)` to an empty
   4-column by 3-row grid area. Tap each of its three purple-named source
   buttons. The metallic rotary adjusts that source's OBS volume from 0–100%,
   and the center **MUTE** button toggles that source's mute state.
8. Check the volume and mute indicators in OBS's Audio Mixer, then drag the
   rotary while monitoring OBS. At a non-round volume such as 47%, confirm
   the purple radial highlight **partially fills** its last segment. Move
   the OBS mixer slider directly and confirm the grid follows without a tap;
   allow roughly one quarter second for the polling interval.
9. With auto-connect enabled, restart OBS and confirm automatic reconnection.

The settings icon now uses the confirmed DiscordNotifier registration pattern:
`Icon:"OBSIcon"` referring to a `Gfxs` entry with `Tiling:"Scale"`. Both
images are 150x150. This sizing still needs a visual test in the restored host.

**Credential warning:** `Type:"Password"` is confirmed to mask input on the
restored host (v0.1.5 runtime test). The plugin does **not** yet implement DPAPI;
masking on screen would not establish encrypted storage. Treat saved settings
as potentially readable text and use a disposable OBS test password.

## Native callable functions

All functions are in the `OBSWebSocket` namespace:

| Name | Arguments | Result |
| --- | --- | --- |
| `Configure` | `[host, port, password]` | Boolean accepted/rejected |
| `Status` | `[]` | `{connected, state, error}` |
| `TileStatus` | `[]` | Plain text: connection state and audio-input count |
| `Inputs` | `[]` | OBS input list |
| `GetVolume` | `[inputName]` | cached linear multiplier or null |
| `GetMute` | `[inputName]` | cached boolean or null |
| `SetVolume` | `[inputName, multiplier]` | Boolean request queued |
| `SetMute` | `[inputName, muted]` | Boolean request queued |
| `AudioSources` | `[]` | Audio inputs with Windows device-friendly names when available |
| `Slot1Label`, `Slot2Label`, `Slot3Label` | `[]` | Configured selector names |
| `Slot1Source`, `Slot2Source`, `Slot3Source` | `[]` | Selected friendly device name or fallback OBS name |
| `GetSlotVolume`, `GetSlotMute` | `["Slot1"/"Slot2"/"Slot3"]` | Cached mixer state |
| `SetSlotVolume`, `SetSlotMute` | `[slot, value]` | Boolean request queued |

Example calls from a custom Power-Grid control script, using the incoming-source bridge:

```javascript
this.CallDataSourceFunc("OBSWebSocket", "Configure", ["127.0.0.1", "4455", password]);
var state = this.CallDataSourceFunc("OBSWebSocket", "TileStatus", []);
var volume = this.CallDataSourceFunc("OBSWebSocket", "GetVolume", ["Desktop Audio"]);
this.CallDataSourceFunc("OBSWebSocket", "SetVolume", ["Desktop Audio", 0.8]);
this.CallDataSourceFunc("OBSWebSocket", "SetMute", ["Mic/Aux", true]);
```

`SetVolume` deliberately accepts **0.0–1.0** for the first UI iteration,
although OBS's protocol supports multipliers up to 20.0. We can expand this
once we decide how the rotary dial should represent gain above unity.

## Protocol references

- [Official OBS WebSocket 5.x protocol](https://github.com/obsproject/obs-websocket/blob/master/docs/generated/protocol.md)
- Relevant methods: `GetInputList`, `GetInputVolume`, `SetInputVolume`,
  `GetInputMute`, `SetInputMute`.
- Relevant events: `InputVolumeChanged`, `InputMuteStateChanged`.

## Known limits of this preview

- **The v0.1.15 persistent mask feed is not yet live-tested.** v0.1.13 was
  confirmed to adjust/mute each source, and v0.1.14 lit the smooth purple
  radial mask only during rotary interaction. Test whether the output refresh
  now keeps the light at its OBS level without flicker or blackouts. The
  synthetic Percent result slot remains a host-specific behaviour to verify
  before GitHub release.
- No TLS, remote-host support or generic network credentials.
- No audio meter subscription or video/rendering work.
- Input discovery currently returns all OBS inputs, including non-audio types;
  volume/mute read failures on those inputs are ignored.
- Input volume events update an in-memory cache; it is not a historical log.
- The three **Choose source** buttons open Qt's native dropdown dialog, because
  Power-Grid's global plugin-settings manifest does not dynamically replace
  `Drop.Items`. They are not inline combo boxes. The list includes OBS audio
  inputs; for device-backed inputs it displays Windows device names obtained
  from OBS's `device_id` property list. Non-device sources fall back to OBS names.
- Selected inputs are saved by OBS input name. A rename event updates the
  assignment while connected. Missing sources remain saved but are displayed
  as unavailable and cannot receive volume/mute commands until reassigned;
  the plugin does not reconfigure OBS capture devices.
- A Choose action takes effect immediately; click the Power-Grid settings
  **Apply** button to save it. This source archive is not an installable binary.
- The rotary uses cached OBS volume/mute states and locally updates those
  states when a request is queued, for smooth feedback; OBS events then
  provide authoritative updates. A disconnected or unassigned source cannot
  receive volume/mute commands.
- The 4x3 control inherits the native ROCCAT hit testing and dial mechanics;
  its new image resources must ship in the RPGP with the compiled DLL.
- Release screenshots should include the import dialogs, OBS server settings,
  the Power-Grid connection/source panel, and the finished purple mixer.
