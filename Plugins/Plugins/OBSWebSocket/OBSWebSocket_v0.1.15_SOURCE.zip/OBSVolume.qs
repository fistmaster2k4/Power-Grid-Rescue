// OBS WebSocket mixer — the original ROCCAT 4x3 rotary mechanics, with
// slot names, source mapping, volume and mute supplied by OBSWebSocket.dll.
// The system-volume control remains untouched.

function InitOBSVolume(skin)
{
    var buttons = [this.FindLayout("Btn_Master"),
                   this.FindLayout("Btn_Mic"),
                   this.FindLayout("Btn_Music")];
    var wheel = this.FindLayout("WheelMask");
    var knob = this.FindLayout("Knob");
    var mute = this.FindLayout("BtnMute");
    var knobDistance = Math.abs((wheel.getY()+wheel.getH()/2) -
                                (knob.getY()+knob.getH()/2));
    skin.data = {
        buttons:buttons,
        wheel:wheel,
        knob:knob,
        mute:mute,
        mode:0,
        volumes:[0,0,0],
        muted:[false,false,false],
        lastDialVolume:-1,
        maskStart:wheel.getMaskStart(),
        maskEnd:wheel.getMaskEnd(),
        knobDistance:knobDistance
    };
    for (var i=0; i<3; ++i) {
        buttons[i].data = {
            bg:buttons[i].findChild("BtnBG"),
            label:buttons[i].findChild("TxtMMM"),
            muted:buttons[i].findChild("Ovl_Muted"),
            currentLabel:"AUDIO "+(i+1)
        };
        buttons[i].data.label.setText("AUDIO "+(i+1));
    }
    // Radial Mask.Input is an IO channel INDEX, not a percent value.
    // Channel 0 is a script-fed Percent result from OBSVolumeMaskFeed.
    wheel.setMaskInput(0);
    this.SetTickInterval(250);
    TickOBSVolume(skin);
}

function OBSVolumeSlot(index) { return "Slot"+(index+1); }

function TickOBSVolume(skin)
{
    var d=skin.data;
    if (!d) return;
    if (typeof this.CallDataSourceFunc !== "function") return;
    var changed=false;
    for (var i=0; i<3; ++i) {
        var slot=OBSVolumeSlot(i);
        var name=this.CallDataSourceFunc("OBSWebSocket",slot+"Label",[]);
        if (typeof name === "string" && name !== "" &&
            name !== d.buttons[i].data.currentLabel) {
            d.buttons[i].data.label.setText(String(name));
            d.buttons[i].data.currentLabel=name;
            changed=true;
        }
        var value=this.CallDataSourceFunc("OBSWebSocket","GetSlotVolume",[slot]);
        if (value !== undefined && value !== null && !isNaN(Number(value))) {
            var amount=Math.max(0,Math.min(1,Number(value)));
            if (Math.abs(amount-d.volumes[i])>0.001) {
                d.volumes[i]=amount;
                if (i==d.mode) changed=true;
            }
        }
        var muted=this.CallDataSourceFunc("OBSWebSocket","GetSlotMute",[slot]);
        if (muted !== undefined && muted !== null) {
            var isMuted=Boolean(muted);
            if (d.muted[i]!==isMuted) changed=true;
            d.muted[i]=isMuted;
        }
        d.buttons[i].data.bg.active=(i==d.mode);
        d.buttons[i].data.muted.visible=d.muted[i];
    }
    d.mute.active=d.muted[d.mode];
    if (Math.abs(d.lastDialVolume-d.volumes[d.mode])>0.001) {
        d.lastDialVolume=d.volumes[d.mode];
        UpdateOBSVolumeKnob(skin,d.knob);
        changed=true;
    }
    // The synthetic function output may be reset by Power-Grid's ordinary
    // function polling even when OBS's level has not changed. Restore the
    // mask's input from the authoritative OBS cache whenever that happens.
    var maskValue=this.GetFuncRes(0,0);
    if (maskValue === undefined || maskValue === null ||
        isNaN(Number(maskValue)) ||
        Math.abs(Number(maskValue)-d.volumes[d.mode])>0.001) {
        this.SetFuncRes(0,0,d.volumes[d.mode]);
        changed=true;
    }
    // The host doesn't reliably repaint/push geometry-only changes to the
    // Android grid without an explicit invalidation.
    if (changed) this.Invalidate();
}

function OnClickOBSSlot(skin,layout)
{
    var d=skin.data;
    var button=layout.getParent();
    if (!button) button=layout;
    for (var i=0; i<3; ++i)
        if (button.name==d.buttons[i].name) d.mode=i;
    d.lastDialVolume=-1;
    TickOBSVolume(skin);
    this.Invalidate();
}

function OnMuteOBSVolume(skin,layout)
{
    var d=skin.data;
    var slot=OBSVolumeSlot(d.mode);
    var next=!d.muted[d.mode];
    var accepted=this.CallDataSourceFunc("OBSWebSocket","SetSlotMute",[slot,next]);
    if (accepted) {
        d.muted[d.mode]=next;
        d.mute.active=next;
        d.buttons[d.mode].data.muted.visible=next;
        this.Invalidate();
    }
}

function UpdateOBSVolumeKnob(skin,layout)
{
    var d=skin.data;
    var amount=d.volumes[d.mode];
    var angle=(d.maskEnd-d.maskStart)*amount+d.maskStart;
    var x=Math.sin(-angle)*d.knobDistance;
    var y=Math.cos(-angle)*d.knobDistance;
    layout.setPos(d.wheel.getX()+d.wheel.getW()/2-layout.getW()/2+x,
                  d.wheel.getY()+d.wheel.getH()/2-layout.getH()/2+y);
}

function OnWheelMoveOBSVolume(skin,layout)
{
    if (!this.GetMousePressed()) return;
    var d=skin.data;
    var x=this.GetMouseLastEvtX()-layout.getW()/2;
    var y=this.GetMouseLastEvtY()-layout.getH()/2;
    var length=Math.sqrt(x*x+y*y);
    if (length<0.01) return;
    x/=length; y/=length;
    var angle=-Math.atan2(x,y);
    if (angle<0) angle+=2*Math.PI;
    angle=Math.max(d.maskStart,Math.min(d.maskEnd,angle));
    var amount=(angle-d.maskStart)/(d.maskEnd-d.maskStart);
    var slot=OBSVolumeSlot(d.mode);
    var accepted=this.CallDataSourceFunc("OBSWebSocket","SetSlotVolume",[slot,amount]);
    if (accepted) {
        d.volumes[d.mode]=amount;
        d.lastDialVolume=amount;
        this.SetFuncRes(0,0,amount);
        UpdateOBSVolumeKnob(skin,d.knob);
        this.Invalidate();
    }
}
