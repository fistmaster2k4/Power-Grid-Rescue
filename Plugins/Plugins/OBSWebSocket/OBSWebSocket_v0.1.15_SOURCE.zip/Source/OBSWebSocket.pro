TEMPLATE = lib
CONFIG += plugin release
QT += core network script gui
TARGET = OBSWebSocket
INCLUDEPATH += ../../PowerGridSDK/include
LIBS += -L../../PowerGridSDK/lib -lRoccatPowerGrid
HEADERS += obswebsocket.h
SOURCES += obswebsocket.cpp
