#include "obswebsocket.h"
#include <QCryptographicHash>
#include <QHostAddress>
#include <QUuid>
#include <QDateTime>
#include <QtGlobal>
#include <QtGui/QInputDialog>

// PDK's x86 /NODEFAULTLIB OpenCRT currently lacks the MSVC floating-point
// marker. The C identifier _fltused is emitted as __fltused on 32-bit COFF.
// This marker supplies no arithmetic implementation; it satisfies the linker.
#if defined(_M_IX86) || defined(__i386__)
extern "C" int _fltused = 0;
#endif

Q_EXPORT_PLUGIN2(OBSWebSocket, OBSWebSocket)

static QByteArray random16()
{
    // Qt 4-compatible UUID-to-16-byte conversion, without newer QUuid APIs.
    QString hex = QUuid::createUuid().toString();
    hex.remove('{'); hex.remove('}'); hex.remove('-');
    return QByteArray::fromHex(hex.toLatin1());
}

// Reused from the confirmed-working DiscordNotifier v0.1.18 implementation.
// Qt 4.8 does not expose QCryptographicHash::Sha256; no extra DLL is needed.
static unsigned int rotr32(unsigned int x, unsigned n) { return (x >> n) | (x << (32 - n)); }
static QByteArray sha256(const QByteArray &data)
{
    static const unsigned int k[64] = {
        0x428a2f98U,0x71374491U,0xb5c0fbcfU,0xe9b5dba5U,0x3956c25bU,0x59f111f1U,0x923f82a4U,0xab1c5ed5U,
        0xd807aa98U,0x12835b01U,0x243185beU,0x550c7dc3U,0x72be5d74U,0x80deb1feU,0x9bdc06a7U,0xc19bf174U,
        0xe49b69c1U,0xefbe4786U,0x0fc19dc6U,0x240ca1ccU,0x2de92c6fU,0x4a7484aaU,0x5cb0a9dcU,0x76f988daU,
        0x983e5152U,0xa831c66dU,0xb00327c8U,0xbf597fc7U,0xc6e00bf3U,0xd5a79147U,0x06ca6351U,0x14292967U,
        0x27b70a85U,0x2e1b2138U,0x4d2c6dfcU,0x53380d13U,0x650a7354U,0x766a0abbU,0x81c2c92eU,0x92722c85U,
        0xa2bfe8a1U,0xa81a664bU,0xc24b8b70U,0xc76c51a3U,0xd192e819U,0xd6990624U,0xf40e3585U,0x106aa070U,
        0x19a4c116U,0x1e376c08U,0x2748774cU,0x34b0bcb5U,0x391c0cb3U,0x4ed8aa4aU,0x5b9cca4fU,0x682e6ff3U,
        0x748f82eeU,0x78a5636fU,0x84c87814U,0x8cc70208U,0x90befffaU,0xa4506cebU,0xbef9a3f7U,0xc67178f2U
    };
    unsigned int h[8] = {0x6a09e667U,0xbb67ae85U,0x3c6ef372U,0xa54ff53aU,0x510e527fU,0x9b05688cU,0x1f83d9abU,0x5be0cd19U};
    QByteArray padded(data);
    const unsigned long long bitlen = static_cast<unsigned long long>(data.size()) * 8ULL;
    padded.append(char(0x80));
    while ((padded.size() % 64) != 56) padded.append(char(0));
    for (int i=7;i>=0;--i) padded.append(char((bitlen >> (i*8)) & 0xffU));
    for (int off=0;off<padded.size();off+=64) {
        unsigned int w[64];
        for (int i=0;i<16;++i) {
            const unsigned char *b=reinterpret_cast<const unsigned char *>(padded.constData()+off+4*i);
            w[i]=(static_cast<unsigned int>(b[0])<<24)|(static_cast<unsigned int>(b[1])<<16)|(static_cast<unsigned int>(b[2])<<8)|b[3];
        }
        for (int i=16;i<64;++i) {
            const unsigned int x=w[i-15], y=w[i-2];
            w[i]=w[i-16]+(rotr32(x,7)^rotr32(x,18)^(x>>3))+w[i-7]+(rotr32(y,17)^rotr32(y,19)^(y>>10));
        }
        unsigned int a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],v=h[7];
        for (int i=0;i<64;++i) {
            const unsigned int s1=rotr32(e,6)^rotr32(e,11)^rotr32(e,25);
            const unsigned int ch=(e&f)^(~e&g);
            const unsigned int t1=v+s1+ch+k[i]+w[i];
            const unsigned int s0=rotr32(a,2)^rotr32(a,13)^rotr32(a,22);
            const unsigned int maj=(a&b)^(a&c)^(b&c);
            const unsigned int t2=s0+maj;
            v=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;
        }
        h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;h[5]+=f;h[6]+=g;h[7]+=v;
    }
    QByteArray digest(32,char(0));
    for (int i=0;i<8;++i) for(int j=0;j<4;++j) digest[i*4+j]=char((h[i]>>(24-8*j))&255);
    return digest;
}

OBSWebSocket::OBSWebSocket()
    : m_host("127.0.0.1"), m_port(4455), m_autoConnect(false),
      m_hasConnected(false), m_state(Offline),
      m_fragmentOpcode(0), m_requestId(0)
{
    m_names << "Configure" << "Connect" << "Disconnect" << "ToggleConnection"
            << "ConnectionButtonText" << "Status" << "TileStatus"
            << "SettingsStatus" << "Inputs" << "GetVolume"
            << "GetMute" << "SetVolume" << "SetMute"
            << "ChooseSlot1" << "ChooseSlot2" << "ChooseSlot3"
            << "Slot1Source" << "Slot2Source" << "Slot3Source"
            << "Slot1Label" << "Slot2Label" << "Slot3Label"
            << "SelectionStatus" << "AudioSources"
            << "GetSlotVolume" << "GetSlotMute" << "SetSlotVolume" << "SetSlotMute";
    connect(&m_socket, SIGNAL(connected()), this, SLOT(connected()));
    connect(&m_socket, SIGNAL(readyRead()), this, SLOT(readyRead()));
    connect(&m_socket, SIGNAL(disconnected()), this, SLOT(disconnected()));
    connect(&m_socket, SIGNAL(error(QAbstractSocket::SocketError)),
            this, SLOT(socketError(QAbstractSocket::SocketError)));
    connect(&m_retry, SIGNAL(timeout()), this, SLOT(reconnect()));
    m_retry.setInterval(3000);
    m_settings.insert("OBSPort", "4455");
    m_settings.insert("AutoConnect", false);
    m_settings.insert("HasConnected", false);
    for (int i=1; i<=3; ++i) {
        const QString prefix = QString("Slot%1").arg(i);
        m_settings.insert(prefix + "Label", QString("AUDIO %1").arg(i));
        m_settings.insert(prefix + "Input", QString());
    }
}

void OBSWebSocket::SetPluginData(PGConfiguration value)
{
    m_settings = value;
    if (!m_settings.contains("OBSPort")) m_settings.insert("OBSPort", "4455");
    if (!m_settings.contains("AutoConnect")) m_settings.insert("AutoConnect", false);
    for (int i=1; i<=3; ++i) {
        const QString prefix = QString("Slot%1").arg(i);
        if (!m_settings.contains(prefix + "Label"))
            m_settings.insert(prefix + "Label", QString("AUDIO %1").arg(i));
        if (!m_settings.contains(prefix + "Input"))
            m_settings.insert(prefix + "Input", QString());
    }
    const int port = m_settings.value("OBSPort").toInt();
    const QString password = m_settings.value("OBSPassword").toString();
    m_autoConnect = m_settings.value("AutoConnect").toBool();
    m_hasConnected = m_settings.value("HasConnected").toBool();
    if (port < 1 || port > 65535) {
        setError("Invalid OBS port (1-65535)");
        return;
    }
    const bool changed = m_port != port || m_password != password;
    m_host = "127.0.0.1";
    m_port = quint16(port);
    m_password = password;
    if (m_autoConnect && m_hasConnected && (changed || m_state == Offline)) restart();
    else if (!m_autoConnect && changed) stopConnection();
    else if (!m_autoConnect) m_retry.stop();
}

PGConfiguration OBSWebSocket::GetPluginData() { return m_settings; }
PGIncomingEntries OBSWebSocket::GetEntries() { return PGIncomingEntries(); }
bool OBSWebSocket::IsActive() { return true; }

QVariant OBSWebSocket::GetValue(QString name, const QVariantList& args)
{
    if (name == "ConnectionButtonText")
        return m_state == Ready ? "Disconnect" : "Connect";
    if (name == "ToggleConnection") {
        if (m_state == Ready) {
            stopConnection();
            return "Disconnected";
        }
        restart();
        return "Connecting";
    }
    if (name == "Connect") {
        if (m_port == 0) return "Invalid port";
        restart();
        return "Connecting";
    }
    if (name == "Disconnect") {
        stopConnection();
        return "Disconnected";
    }
    if (name == "SettingsStatus")
        return QString("OBS WebSocket: ") +
               (m_state == Ready ? "Connected" :
                m_state == Offline ? "Disconnected" : "Connecting") +
               (m_error.isEmpty() ? QString() : QString(" - ") + m_error);
    if (name == "TileStatus") {
        if (m_state == Ready) {
            int audioCount=0;
            for (QMap<QString,QVariantMap>::const_iterator it=m_audio.begin();
                 it!=m_audio.end(); ++it)
                if (it.value().contains("volume")) ++audioCount;
            return QString("Connected (%1 audio inputs)").arg(audioCount);
        }
        return (m_state == Offline ? QString("Disconnected") : QString("Connecting")) +
               (m_error.isEmpty() ? QString() : QString("\n") + m_error);
    }
    if (name == "Configure") {
        if (args.size() < 3) return false;
        const QString host = args[0].toString().trimmed().toLower();
        const int port = args[1].toInt();
        // v0.1 deliberately supports local OBS only, never an exposed listener.
        if ((host != "127.0.0.1" && host != "localhost") || port < 1 || port > 65535)
            return false;
        const QString password = args[2].toString();
        if (host != m_host || port != m_port || password != m_password || !m_retry.isActive()) {
            m_host = host; m_port = quint16(port); m_password = password;
            restart();
        }
        return true;
    }
    if (name == "Status") {
        QVariantMap s;
        s.insert("connected", m_state == Ready);
        s.insert("state", m_state == Ready ? "Connected" :
                 m_state == Offline ? "Disconnected" : "Connecting");
        s.insert("error", m_error);
        return s;
    }
    if (name == "Inputs") return m_inputs;
    if (name == "AudioSources") {
        QVariantList sources;
        for (int i=0; i<m_inputs.size(); ++i) {
            const QString input=m_inputs[i].toMap().value("inputName").toString();
            if (m_audio.value(input).contains("volume")) {
                QVariantMap item;
                item.insert("inputName", input);
                item.insert("deviceName", sourceLabel(input));
                sources.append(item);
            }
        }
        return sources;
    }
    if (name == "SelectionStatus") return m_selectionMessage;
    for (int i=1; i<=3; ++i) {
        const QString slot=QString("Slot%1").arg(i);
        if (name == "Choose" + slot) return chooseAudioInput(slot);
        if (name == slot + "Label") return m_settings.value(slot + "Label");
        if (name == slot + "Source") {
            const QString input=slotInput(slot);
            if (input.isEmpty()) return QString("Not assigned");
            if (m_state == Ready && !m_audio.value(input).contains("volume"))
                return QString("Unavailable: ") + input;
            return sourceLabel(input);
        }
    }
    if (name == "GetSlotVolume" || name == "GetSlotMute" ||
        name == "SetSlotVolume" || name == "SetSlotMute") {
        if (args.isEmpty()) return QVariant();
        const QString input=slotInput(args[0].toString());
        if (input.isEmpty()) return QVariant();
        if (name == "GetSlotVolume") return m_audio.value(input).value("volume");
        if (name == "GetSlotMute") return m_audio.value(input).value("muted");
        if (m_state != Ready || args.size() < 2 ||
            !m_audio.value(input).contains("volume")) return false;
        QVariantMap data; data.insert("inputName", input);
        if (name == "SetSlotVolume") {
            const double mul=args[1].toDouble();
            if (mul < 0.0 || mul > 1.0 || mul != mul) return false;
            data.insert("inputVolumeMul", mul);
            request("SetInputVolume", data);
            // Keep the local dial responsive until OBS sends the next
            // InputVolumeChanged event (the authoritative value).
            QVariantMap item=m_audio.value(input);
            item.insert("volume", mul);
            m_audio[input]=item;
        } else {
            const bool muted=args[1].toBool();
            data.insert("inputMuted", muted);
            request("SetInputMute", data);
            QVariantMap item=m_audio.value(input);
            item.insert("muted", muted);
            m_audio[input]=item;
        }
        return true;
    }
    if (args.size() < 1) return QVariant();
    const QString input = args[0].toString();
    if (name == "GetVolume") return m_audio.value(input).value("volume");
    if (name == "GetMute") return m_audio.value(input).value("muted");
    if (m_state != Ready || input.isEmpty()) return false;
    QVariantMap data;
    data.insert("inputName", input);
    if (name == "SetVolume" && args.size() > 1) {
        const double mul = args[1].toDouble();
        // UI safety range; OBS itself accepts up to 20.0.
        if (mul < 0.0 || mul > 1.0 || mul != mul) return false;
        data.insert("inputVolumeMul", mul);
        request("SetInputVolume", data);
        return true;
    }
    if (name == "SetMute" && args.size() > 1) {
        data.insert("inputMuted", args[1].toBool());
        request("SetInputMute", data);
        return true;
    }
    return QVariant();
}

QString OBSWebSocket::slotInput(const QString& value) const
{
    QString slot=value.trimmed();
    if (slot == "1" || slot == "2" || slot == "3") slot.prepend("Slot");
    if (slot != "Slot1" && slot != "Slot2" && slot != "Slot3") return QString();
    return m_settings.value(slot + "Input").toString();
}

QString OBSWebSocket::sourceLabel(const QString& input) const
{
    return m_deviceLabels.value(input, input);
}

void OBSWebSocket::updateDeviceLabel(const QString& input)
{
    const QVariantMap settings=m_inputSettings.value(input);
    QString value=settings.value("device_id").toString();
    if (value.isEmpty()) value=settings.value("device").toString();
    const QVariantList choices=m_deviceOptions.value(input);
    for (int i=0; i<choices.size(); ++i) {
        const QVariantMap choice=choices[i].toMap();
        if (choice.value("itemValue").toString() == value) {
            const QString label=choice.value("itemName").toString();
            if (!label.isEmpty()) { m_deviceLabels[input]=label; return; }
        }
    }
    m_deviceLabels.remove(input);
}

QString OBSWebSocket::chooseAudioInput(const QString& slot)
{
    if (m_state != Ready) { m_selectionMessage="Connect to OBS first"; return m_selectionMessage; }
    QStringList display;
    QStringList inputs;
    for (int i=0; i<m_inputs.size(); ++i) {
        const QString input=m_inputs[i].toMap().value("inputName").toString();
        if (!m_audio.value(input).contains("volume")) continue;
        QString label=sourceLabel(input);
        // Keep a Windows device's friendly name whenever available. If two OBS
        // inputs share it, append the OBS name to make the choices unambiguous.
        bool duplicate=false;
        for (int j=0; j<m_inputs.size(); ++j) {
            const QString other=m_inputs[j].toMap().value("inputName").toString();
            if (other != input && m_audio.value(other).contains("volume") &&
                sourceLabel(other) == label) { duplicate=true; break; }
        }
        if (duplicate) label += " (" + input + ")";
        display.append(label);
        inputs.append(input);
    }
    if (display.isEmpty()) { m_selectionMessage="No OBS audio inputs found"; return m_selectionMessage; }
    const QString current=slotInput(slot);
    const int currentIndex=qMax(0,inputs.indexOf(current));
    bool accepted=false;
    const QString selection=QInputDialog::getItem(NULL, "OBS Audio Source",
        m_settings.value(slot + "Label",slot).toString() + ":", display,
        currentIndex, false, &accepted);
    if (!accepted) return QString();
    const int selected=display.indexOf(selection);
    if (selected < 0) return QString();
    m_settings.insert(slot + "Input", inputs.at(selected));
    m_selectionMessage=m_settings.value(slot + "Label",slot).toString() +
        " assigned to " + sourceLabel(inputs.at(selected)) + " (click Apply to save)";
    return m_selectionMessage;
}

void OBSWebSocket::restart()
{
    stopConnection();
    m_state = Offline;
    m_buffer.clear(); m_fragments.clear(); m_fragmentOpcode = 0;
    m_audio.clear(); m_inputs.clear(); m_error.clear();
    m_inputSettings.clear(); m_deviceOptions.clear(); m_deviceLabels.clear();
    if (m_autoConnect && m_hasConnected) m_retry.start();
    reconnect();
}

void OBSWebSocket::stopConnection()
{
    m_retry.stop();
    m_socket.abort();
    m_state = Offline;
    m_audio.clear();
    m_inputs.clear();
    m_inputSettings.clear(); m_deviceOptions.clear(); m_deviceLabels.clear();
    m_error.clear();
}

void OBSWebSocket::reconnect()
{
    if (m_socket.state() != QAbstractSocket::UnconnectedState) return;
    m_buffer.clear(); m_fragments.clear(); m_fragmentOpcode = 0;
    m_socket.connectToHost(m_host, m_port);
}

void OBSWebSocket::connected()
{
    m_state = HttpUpgrade;
    // Each connection has a unique WebSocket key.
    m_key = random16().toBase64();
    QByteArray req = "GET / HTTP/1.1\r\nHost: " + m_host.toLatin1() + ":" +
                     QByteArray::number(m_port) + "\r\n";
    req += "Upgrade: websocket\r\nConnection: Upgrade\r\n";
    req += "Sec-WebSocket-Key: " + m_key + "\r\nSec-WebSocket-Version: 13\r\n";
    req += "Sec-WebSocket-Protocol: obswebsocket.json\r\n\r\n";
    m_socket.write(req);
}

void OBSWebSocket::readyRead()
{
    m_buffer += m_socket.readAll();
    if (m_buffer.size() > 2 * 1024 * 1024) {
        setError("Oversized WebSocket message"); m_socket.abort(); return;
    }
    if (m_state == HttpUpgrade) {
        int end = m_buffer.indexOf("\r\n\r\n");
        if (end < 0) return;
        QByteArray hdr = m_buffer.left(end + 4);
        m_buffer.remove(0, end + 4);
        QByteArray magic = m_key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
        QByteArray accept = QCryptographicHash::hash(magic, QCryptographicHash::Sha1).toBase64();
        if (!hdr.startsWith("HTTP/1.1 101 ") ||
            !hdr.toLower().contains("upgrade: websocket") ||
            !hdr.toLower().contains("connection: upgrade") ||
            !hdr.contains("Sec-WebSocket-Accept: " + accept)) {
            setError("WebSocket HTTP upgrade rejected"); m_socket.abort(); return;
        }
        m_state = AwaitHello;
    }
    consumeFrames();
}

void OBSWebSocket::consumeFrames()
{
    while (m_buffer.size() >= 2 && m_state != Offline) {
        const quint8 a = quint8(m_buffer[0]), b = quint8(m_buffer[1]);
        const bool fin = (a & 0x80) != 0;
        const quint8 opcode = a & 0x0f;
        if ((a & 0x70) || (b & 0x80)) { m_socket.abort(); return; }
        quint64 len = b & 0x7f;
        int header = 2;
        if (len == 126) {
            if (m_buffer.size() < 4) return;
            len = (quint8(m_buffer[2]) << 8) | quint8(m_buffer[3]);
            header = 4;
        } else if (len == 127) {
            if (m_buffer.size() < 10) return;
            len = 0;
            for (int i = 2; i < 10; ++i) len = (len << 8) | quint8(m_buffer[i]);
            header = 10;
        }
        if (len > 1024 * 1024) { setError("WebSocket frame too large"); m_socket.abort(); return; }
        if (m_buffer.size() < header + qint64(len)) return;
        const QByteArray bytes = m_buffer.mid(header, int(len));
        m_buffer.remove(0, header + int(len));
        if (opcode == 8) { sendFrame(8, bytes.left(125)); m_socket.disconnectFromHost(); return; }
        if (opcode == 9) { sendFrame(10, bytes.left(125)); continue; }
        if (opcode == 10) continue;
        if (opcode != 0 && opcode != 1) { m_socket.abort(); return; }
        if (opcode == 1 && m_fragmentOpcode) { m_socket.abort(); return; }
        if (opcode == 0 && !m_fragmentOpcode) { m_socket.abort(); return; }
        if (opcode == 1) m_fragmentOpcode = 1;
        m_fragments += bytes;
        if (m_fragments.size() > 1024 * 1024) { m_socket.abort(); return; }
        if (fin) {
            processMessage(m_fragments);
            m_fragments.clear(); m_fragmentOpcode = 0;
        }
    }
}

void OBSWebSocket::sendFrame(quint8 opcode, const QByteArray& data)
{
    if (m_socket.state() != QAbstractSocket::ConnectedState) return;
    QByteArray frame;
    frame.append(char(0x80 | opcode));
    if (data.size() < 126) frame.append(char(0x80 | data.size()));
    else if (data.size() <= 65535) {
        frame.append(char(0x80 | 126));
        frame.append(char((data.size() >> 8) & 0xff));
        frame.append(char(data.size() & 0xff));
    } else {
        frame.append(char(0x80 | 127));
        for (int i = 7; i >= 0; --i) frame.append(char((quint64(data.size()) >> (8*i)) & 0xff));
    }
    const QByteArray mask = random16().left(4);
    frame += mask;
    for (int i = 0; i < data.size(); ++i) frame.append(char(data[i] ^ mask[i % 4]));
    m_socket.write(frame);
}

QString OBSWebSocket::quote(const QString& value)
{
    QString result = "\"";
    for (int i = 0; i < value.size(); ++i) {
        ushort c = value.at(i).unicode();
        if (c == '"') result += "\\\"";
        else if (c == '\\') result += "\\\\";
        else if (c == '\n') result += "\\n";
        else if (c == '\r') result += "\\r";
        else if (c == '\t') result += "\\t";
        else if (c < 32) result += QString("\\u%1").arg(c,4,16,QChar('0'));
        else result += QChar(c);
    }
    return result + "\"";
}

QByteArray OBSWebSocket::json(const QVariant& value)
{
    if (!value.isValid() || value.isNull()) return "null";
    if (value.type() == QVariant::Map) {
        const QVariantMap map = value.toMap();
        QByteArray out = "{";
        for (QVariantMap::const_iterator i=map.begin(); i!=map.end(); ++i) {
            if (i!=map.begin()) out += ',';
            out += quote(i.key()).toUtf8() + ':' + json(i.value());
        }
        return out + '}';
    }
    if (value.type() == QVariant::List) {
        QByteArray out = "[";
        QVariantList list=value.toList();
        for (int i=0; i<list.size(); ++i) { if(i) out += ','; out += json(list[i]); }
        return out + ']';
    }
    if (value.type() == QVariant::Bool) return value.toBool() ? "true" : "false";
    if (value.type() == QVariant::Int || value.type() == QVariant::UInt ||
        value.type() == QVariant::LongLong || value.type() == QVariant::ULongLong ||
        value.type() == QVariant::Double) return QByteArray::number(value.toDouble(), 'g', 16);
    return quote(value.toString()).toUtf8();
}

QVariant OBSWebSocket::parse(const QByteArray& bytes)
{
    // JSON.parse validates rather than evaluating arbitrary JavaScript.
    QScriptValue jsonObj = m_script.globalObject().property("JSON");
    QScriptValue parseFn = jsonObj.property("parse");
    if (!parseFn.isFunction()) return QVariant();
    QScriptValueList args;
    args << QScriptValue(&m_script, QString::fromUtf8(bytes));
    QScriptValue parsed = parseFn.call(jsonObj, args);
    if (m_script.hasUncaughtException()) { m_script.clearExceptions(); return QVariant(); }
    return parsed.toVariant();
}

void OBSWebSocket::sendJson(const QVariantMap& message)
{
    sendFrame(1, json(message));
}

void OBSWebSocket::request(const QString& type, const QVariantMap& data)
{
    if (m_state != Ready) return;
    QVariantMap d;
    d.insert("requestType", type);
    QString id = QString::number(++m_requestId);
    if (data.contains("inputName")) id += ":" + data.value("inputName").toString();
    d.insert("requestId", id);
    if (!data.isEmpty()) d.insert("requestData", data);
    QVariantMap envelope;
    envelope.insert("op", 6); envelope.insert("d", d);
    sendJson(envelope);
}

void OBSWebSocket::processMessage(const QByteArray& bytes)
{
    QVariant payload = parse(bytes);
    if (payload.type() != QVariant::Map) return;
    QVariantMap envelope = payload.toMap();
    const int op = envelope.value("op").toInt();
    const QVariantMap d = envelope.value("d").toMap();
    if (op == 0 && m_state == AwaitHello) {
        QVariantMap identify;
        identify.insert("rpcVersion", 1);
        // Inputs=8; no InputVolumeMeters high-volume subscription.
        identify.insert("eventSubscriptions", 8);
        QVariantMap auth = d.value("authentication").toMap();
        if (!auth.isEmpty()) {
            const QByteArray salt = auth.value("salt").toString().toUtf8();
            const QByteArray challenge = auth.value("challenge").toString().toUtf8();
            if (m_password.isEmpty() || salt.isEmpty() || challenge.isEmpty()) {
                setError("OBS authentication password required"); m_socket.abort(); return;
            }
            QByteArray secret = sha256(m_password.toUtf8()+salt).toBase64();
            QByteArray proof = sha256(secret+challenge).toBase64();
            identify.insert("authentication", QString::fromLatin1(proof));
        }
        QVariantMap out; out.insert("op", 1); out.insert("d", identify);
        sendJson(out); m_state = AwaitIdentified;
        return;
    }
    if (op == 2 && m_state == AwaitIdentified) {
        m_state = Ready; m_error.clear();
        m_hasConnected = true;
        m_settings.insert("HasConnected", true);
        if (m_autoConnect && !m_retry.isActive()) m_retry.start();
        request("GetInputList"); return;
    }
    if (op == 5 && m_state == Ready) {
        const QString event = d.value("eventType").toString();
        const QVariantMap data = d.value("eventData").toMap();
        const QString name = data.value("inputName").toString();
        if (event == "InputVolumeChanged" && !name.isEmpty()) {
            QVariantMap item = m_audio.value(name);
            item.insert("volume", data.value("inputVolumeMul")); m_audio[name]=item;
        } else if (event == "InputMuteStateChanged" && !name.isEmpty()) {
            QVariantMap item = m_audio.value(name);
            item.insert("muted", data.value("inputMuted")); m_audio[name]=item;
        } else if (event == "InputNameChanged") {
            const QString oldName=data.value("oldInputName").toString();
            if (!oldName.isEmpty() && !name.isEmpty()) {
                if (m_audio.contains(oldName)) m_audio[name]=m_audio.take(oldName);
                if (m_inputSettings.contains(oldName)) m_inputSettings[name]=m_inputSettings.take(oldName);
                if (m_deviceOptions.contains(oldName)) m_deviceOptions[name]=m_deviceOptions.take(oldName);
                if (m_deviceLabels.contains(oldName)) m_deviceLabels[name]=m_deviceLabels.take(oldName);
                for (int i=1; i<=3; ++i) {
                    const QString key=QString("Slot%1Input").arg(i);
                    if (m_settings.value(key).toString() == oldName) m_settings.insert(key,name);
                }
            }
            request("GetInputList");
        } else if (event == "InputCreated" || event == "InputRemoved") request("GetInputList");
        else if (event == "InputSettingsChanged" && !name.isEmpty()) {
            QVariantMap req; req.insert("inputName",name);
            request("GetInputSettings", req);
            req.insert("propertyName","device_id");
            request("GetInputPropertiesListPropertyItems", req);
        }
        return;
    }
    if (op == 7 && m_state == Ready) {
        const QVariantMap status = d.value("requestStatus").toMap();
        if (!status.value("result").toBool()) {
            const QString failed = d.value("requestType").toString();
            // GetInputList includes non-audio inputs: querying their volume
            // may fail legitimately and must not report a connection error.
            if (failed != "GetInputVolume" && failed != "GetInputMute" &&
                failed != "GetInputSettings" &&
                failed != "GetInputPropertiesListPropertyItems")
                setError(failed + ": " + status.value("comment").toString());
            return;
        }
        const QString type = d.value("requestType").toString();
        const QVariantMap response = d.value("responseData").toMap();
        if (type == "GetInputList") {
            m_inputs = response.value("inputs").toList();
            for (int i=0; i<m_inputs.size(); ++i) {
                const QString input=m_inputs[i].toMap().value("inputName").toString();
                if (input.isEmpty()) continue;
                QVariantMap data; data.insert("inputName",input);
                request("GetInputVolume", data); request("GetInputMute", data);
            }
        } else if (type == "GetInputVolume" || type == "GetInputMute") {
            QString id=d.value("requestId").toString();
            QString input=id.mid(id.indexOf(':')+1);
            if (!input.isEmpty()) {
                QVariantMap item=m_audio.value(input);
                if (type == "GetInputVolume") {
                    item.insert("volume",response.value("inputVolumeMul"));
                    QVariantMap req; req.insert("inputName",input);
                    request("GetInputSettings", req);
                    req.insert("propertyName", "device_id");
                    request("GetInputPropertiesListPropertyItems", req);
                }
                else item.insert("muted",response.value("inputMuted"));
                m_audio[input]=item;
            }
        } else if (type == "GetInputSettings" || type == "GetInputPropertiesListPropertyItems") {
            const QString id=d.value("requestId").toString();
            const int colon=id.indexOf(':');
            const QString input=colon>=0 ? id.mid(colon+1) : QString();
            if (!input.isEmpty()) {
                if (type == "GetInputSettings")
                    m_inputSettings[input]=response.value("inputSettings").toMap();
                else
                    m_deviceOptions[input]=response.value("propertyItems").toList();
                updateDeviceLabel(input);
            }
        }
    }
}

void OBSWebSocket::setError(const QString& error) { m_error = error; }
void OBSWebSocket::disconnected() { m_state = Offline; m_audio.clear(); m_inputs.clear(); }
void OBSWebSocket::socketError(QAbstractSocket::SocketError)
{
    if (m_error.isEmpty()) setError(m_socket.errorString());
}
