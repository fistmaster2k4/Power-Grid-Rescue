#ifndef PG_OBS_WEBSOCKET_H
#define PG_OBS_WEBSOCKET_H

#include "RoccatPowerGrid.h"
#include <QTcpSocket>
#include <QTimer>
#include <QScriptEngine>

// OBS WebSocket 5.x, JSON, loopback only. This plugin does not expose a server.
class OBSWebSocket : public IIncomingDataSource
{
    Q_OBJECT
    Q_INTERFACES(IIncomingDataSource)
public:
    OBSWebSocket();
    virtual QString GetName() { return "OBSWebSocket"; }
    virtual const QStringList& GetList() { return m_names; }
    virtual QVariant GetValue(QString name, const QVariantList& args);
    virtual void SetPluginData(PGConfiguration value);
    virtual PGConfiguration GetPluginData();
    virtual PGIncomingEntries GetEntries();
    virtual bool IsActive();

private slots:
    void connected();
    void readyRead();
    void disconnected();
    void socketError(QAbstractSocket::SocketError);
    void reconnect();

private:
    enum State { Offline, HttpUpgrade, AwaitHello, AwaitIdentified, Ready };
    void restart();
    void stopConnection();
    void consumeFrames();
    void processMessage(const QByteArray& bytes);
    void sendJson(const QVariantMap& message);
    void sendFrame(quint8 opcode, const QByteArray& data);
    void request(const QString& type, const QVariantMap& data = QVariantMap());
    QString chooseAudioInput(const QString& slot);
    QString slotInput(const QString& slot) const;
    QString sourceLabel(const QString& input) const;
    void updateDeviceLabel(const QString& input);
    void setError(const QString& error);
    static QString quote(const QString& text);
    static QByteArray json(const QVariant& value);
    QVariant parse(const QByteArray& jsonBytes);
    QString m_host;
    quint16 m_port;
    QString m_password;
    PGConfiguration m_settings;
    bool m_autoConnect;
    bool m_hasConnected;
    QString m_error;
    State m_state;
    QTcpSocket m_socket;
    QTimer m_retry;
    QByteArray m_buffer;
    QByteArray m_fragments;
    QByteArray m_key;
    quint8 m_fragmentOpcode;
    QStringList m_names;
    QVariantList m_inputs;
    QMap<QString,QVariantMap> m_audio;
    QMap<QString,QVariantMap> m_inputSettings;
    QMap<QString,QVariantList> m_deviceOptions;
    QMap<QString,QString> m_deviceLabels;
    QString m_selectionMessage;
    quint64 m_requestId;
    QScriptEngine m_script;
};

#endif
